# Godot Open Dialogue

An open-source (CC-BY) non-linear dialogue system for Godot (3.1 beta 11).

# Main features

See the /docs/docs.html for features and more details.